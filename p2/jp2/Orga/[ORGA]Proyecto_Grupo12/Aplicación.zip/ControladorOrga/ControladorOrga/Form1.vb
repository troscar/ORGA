﻿Imports System.Threading

Public Class Form1
    Dim cadena As String
    Dim velocidad As String
    Dim tiempo As String
    Dim direccion As String




    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Button1.BackColor = Color.LimeGreen
        'Button2.BackColor = DefaultBackColor
        'Button3.BackColor = DefaultBackColor
        'Button4.BackColor = DefaultBackColor
        buscapuerto()
    End Sub


    Public envio As Char = "!"


    Public Function MostrarBinario(ByVal numero As Int32) As String
        Dim binario As String = ""
        Do While numero >= 2
            binario = (numero Mod 2) & binario
            numero = Int(numero / 2)
        Loop
        binario = numero & binario
        For i = binario.Length To 8
            binario = "0" & binario
        Next
        Return binario
    End Function


    Public Sub EnviarPorPuertoSerial(ByVal caracter As String)
        If SerialPort1.IsOpen Then
            Dim bits As Byte() = New Byte(0) {}
            bits(0) = Convert.ToByte(caracter.Substring(0, 8), 2)

            SerialPort1.Write(bits, 0, bits.Length)


            MessageBox.Show("Se envió: " & caracter)
        Else
            MessageBox.Show("NO HAY CONEXION")
        End If
    End Sub

    Public Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        obtenerTiempo()
        obtenerVelocidad()
        cadena = velocidad + direccion + tiempo
        EnviarPorPuertoSerial(cadena)
        cadena = velocidad + direccion + "0000"
        Thread.Sleep(500)
        EnviarPorPuertoSerial(cadena)


    End Sub

    Private Sub obtenerVelocidad()
        If (ComboBox2.Text.Equals("Baja")) Then
            velocidad = "01"

        End If
        If (ComboBox2.Text.Equals("Media")) Then
            velocidad = "10"

        End If
        If (ComboBox2.Text.Equals("Alta")) Then
            velocidad = "11"
        End If
    End Sub

    Private Sub obtenerTiempo()
        If (ComboBox3.Text.Equals("1")) Then
            tiempo = "0001"
        End If
        If (ComboBox3.Text.Equals("2")) Then
            tiempo = "0010"
        End If
        If (ComboBox3.Text.Equals("3")) Then
            tiempo = "0011"
        End If
        If (ComboBox3.Text.Equals("4")) Then
            tiempo = "0100"
        End If
        If (ComboBox3.Text.Equals("5")) Then
            tiempo = "0101"
        End If
        If (ComboBox3.Text.Equals("6")) Then
            tiempo = "0110"
        End If
        If (ComboBox3.Text.Equals("7")) Then
            tiempo = "0111"
        End If
        If (ComboBox3.Text.Equals("8")) Then
            tiempo = "1000"
        End If
        If (ComboBox3.Text.Equals("9")) Then
            tiempo = "1001"
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        direccion = "10"
        Button1.BackColor = Color.PaleVioletRed
        Button2.BackColor = DefaultBackColor
        Button3.BackColor = DefaultBackColor
        Button4.BackColor = DefaultBackColor
        envio = " "
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        direccion = "00"

        Button1.BackColor = DefaultBackColor
        Button2.BackColor = Color.PaleVioletRed
        Button3.BackColor = DefaultBackColor
        Button4.BackColor = DefaultBackColor
        envio = "B"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        direccion = "11"

        Button1.BackColor = DefaultBackColor
        Button2.BackColor = DefaultBackColor
        Button3.BackColor = Color.PaleVioletRed
        Button4.BackColor = DefaultBackColor
        envio = "D"
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        direccion = "01"

        Button1.BackColor = DefaultBackColor
        Button2.BackColor = DefaultBackColor
        Button3.BackColor = DefaultBackColor
        Button4.BackColor = Color.PaleVioletRed
        envio = "F"
    End Sub

    Private Sub buscapuerto()
        Try
            ComboBox1.Items.Clear()
            For Each puerto As String In My.Computer.Ports.SerialPortNames
                ComboBox1.Items.Add(puerto)
            Next
            If ComboBox1.Items.Count > 0 Then
                ComboBox1.SelectedIndex = 0
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub DesconectarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DesconectarToolStripMenuItem.Click
        SerialPort1.Close()
        MessageBox.Show("DESCONECTADO")
    End Sub


    Private Sub ConectarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConectarToolStripMenuItem.Click
        Try
            With SerialPort1
                .BaudRate = 300
                .DataBits = 8
                .Parity = IO.Ports.Parity.None
                .StopBits = 1
                .PortName = ComboBox1.Text
                .Open()

                If .IsOpen Then
                    MessageBox.Show("CONECTADO")
                Else
                    MessageBox.Show("CONEXION FALLIDA")
                End If
            End With
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub SerialPort1_DataReceived(sender As Object, e As IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        Dim buffer As String
        buffer = SerialPort1.ReadExisting

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub
End Class
